from django.apps import AppConfig


class TransConfig(AppConfig):
    name = 'trans'
